<?php
/**
 * Plugin Name: Talim Certificates (Tutor LMS)
 * Description: Админка для генерации сертификатов (2 страницы PDF) по курсам Tutor LMS с авто-нумерацией TP1225-001.
 * Version: 1.1.0
 */

if (!defined('ABSPATH')) exit;

class Talim_Certificates_Plugin {
    const VERSION = '1.1.0';
    const TABLE = 'talim_certificates';
    const OPTION_PREFIX = 'talim_cert_prefix'; // TP1225
    const OPTION_GRADE  = 'talim_cert_default_grade';
    const OPTION_DB_VERSION = 'talim_cert_db_version';
    const DEFAULT_PREFIX = 'TP1225';
    const DEFAULT_GRADE  = 'зачтено'; // временно, пока заказчик не определил итоговое оценивание
    const PER_PAGE = 50;

    // Нумерация старой версии плагина (talim-certificates777.php) — чтобы номера не повторились
    const LEGACY_OPTION_PREFIX   = 'talim_certificates_prefix';
    const LEGACY_OPTION_LAST_NUM = 'talim_certificates_last_num';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'maybe_install']);
        add_action('admin_post_talim_generate_certificate', [__CLASS__, 'handle_generate']);
        add_action('admin_post_talim_download_certificate', [__CLASS__, 'handle_download']);
        add_action('admin_post_talim_save_cert_settings', [__CLASS__, 'handle_save_settings']);

        // Шаблоны (куда положить фоновые картинки):
        // wp-content/uploads/talim-cert-templates/certificate_bg.png
        // wp-content/uploads/talim-cert-templates/appendix_bg.png
    }

    public static function db_table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function maybe_install() {
        // таблицу создаём/обновляем только при смене версии, а не на каждой загрузке админки
        if (get_option(self::OPTION_DB_VERSION) === self::VERSION) return;

        global $wpdb;
        $table = self::db_table();
        $charset_collate = $wpdb->get_charset_collate();

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            prefix VARCHAR(20) NOT NULL,
            serial INT UNSIGNED NOT NULL,
            number_full VARCHAR(40) NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            course_id BIGINT UNSIGNED NOT NULL,
            issued_at DATETIME NOT NULL,
            pdf_path TEXT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'issued',
            PRIMARY KEY  (id),
            UNIQUE KEY uniq_prefix_serial (prefix, serial),
            UNIQUE KEY uniq_user_course_prefix (prefix, user_id, course_id)
        ) {$charset_collate};";

        dbDelta($sql);

        if (!get_option(self::OPTION_PREFIX)) {
            add_option(self::OPTION_PREFIX, self::DEFAULT_PREFIX);
        }
        if (!get_option(self::OPTION_GRADE)) {
            add_option(self::OPTION_GRADE, self::DEFAULT_GRADE);
        }

        self::ensure_dirs();
        update_option(self::OPTION_DB_VERSION, self::VERSION);
    }

    public static function menu() {
        add_menu_page(
            'Сертификаты',
            'Сертификаты',
            'manage_options',
            'talim-certificates',
            [__CLASS__, 'page'],
            'dashicons-awards',
            56
        );
    }

    private static function page_url($args = []) {
        return add_query_arg(array_merge(['page' => 'talim-certificates'], $args), admin_url('admin.php'));
    }

    private static function redirect($args) {
        wp_safe_redirect(self::page_url($args));
        exit;
    }

    private static function tutor_course_post_type() {
        if (function_exists('tutor') && !empty(tutor()->course_post_type)) {
            return tutor()->course_post_type;
        }
        foreach (['courses', 'tutor_course', 'course'] as $pt) {
            if (post_type_exists($pt)) return $pt;
        }
        return 'courses';
    }

    private static function ensure_tcpdf_loaded() {
        if (class_exists('TCPDF')) return true;

        $lib = plugin_dir_path(__FILE__) . 'lib/tcpdf/tcpdf.php';
        if (file_exists($lib)) {
            require_once $lib;
        }
        return class_exists('TCPDF');
    }

    private static function uploads_dir() {
        $u = wp_upload_dir();
        return rtrim($u['basedir'], '/\\');
    }

    private static function templates_dir() {
        return self::uploads_dir() . '/talim-cert-templates';
    }

    private static function certs_dir() {
        return self::uploads_dir() . '/talim-certificates';
    }

    private static function template_paths() {
        $dir = self::templates_dir();
        return [
            'cert' => $dir . '/certificate_bg.png',
            'appx' => $dir . '/appendix_bg.png',
        ];
    }

    private static function ensure_dirs() {
        $tpl = self::templates_dir();
        $out = self::certs_dir();
        if (!file_exists($tpl)) wp_mkdir_p($tpl);
        if (!file_exists($out)) wp_mkdir_p($out);

        // Сертификаты содержат ФИО — закрываем папку от прямого доступа (Apache/LiteSpeed).
        // Скачивание — только через админку (handle_download).
        $htaccess = $out . '/.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess,
                "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n" .
                "<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n"
            );
        }
        if (!file_exists($out . '/index.php')) {
            @file_put_contents($out . '/index.php', "<?php\n// Silence is golden.\n");
        }
    }

    private static function tutor_progress_percent($course_id, $user_id) {
        if (!function_exists('tutor_utils')) return 0;
        $tu = tutor_utils();

        if (method_exists($tu, 'is_completed_course') && $tu->is_completed_course($course_id, $user_id)) {
            return 100;
        }

        if (method_exists($tu, 'get_course_completed_percent')) {
            $p = $tu->get_course_completed_percent($course_id, $user_id);
            return is_numeric($p) ? (int) round($p) : 0;
        }

        return 0;
    }

    private static function get_user_fullname($user_id) {
        $u = get_userdata($user_id);
        if (!$u) return '';

        $first = trim(get_user_meta($user_id, 'first_name', true));
        $last  = trim(get_user_meta($user_id, 'last_name', true));
        $patr  = trim(get_user_meta($user_id, '_patronymic', true)); // отчество в usermeta

        // ФИО (как у вас на сертификате)
        $parts = array_filter([$last, $first, $patr]);
        $fio = trim(implode(' ', $parts));

        if ($fio === '') $fio = trim($u->display_name);
        return $fio;
    }

    /**
     * Период обучения: дата записи на курс — дата завершения курса (Tutor LMS).
     */
    private static function course_period($course_id, $user_id) {
        global $wpdb;

        $start = $wpdb->get_var($wpdb->prepare(
            "SELECT post_date FROM {$wpdb->posts}
             WHERE post_type = 'tutor_enrolled' AND post_parent = %d AND post_author = %d
             ORDER BY ID DESC LIMIT 1",
            $course_id, $user_id
        ));

        $end = '';
        if (function_exists('tutor_utils') && method_exists(tutor_utils(), 'is_completed_course')) {
            $completed = tutor_utils()->is_completed_course($course_id, $user_id);
            if ($completed && !empty($completed->completion_date)) {
                $end = $completed->completion_date;
            }
        }

        $fmt = function ($mysql) {
            $ts = $mysql ? strtotime($mysql) : false;
            return $ts ? date('d.m.Y', $ts) : date_i18n('d.m.Y');
        };

        return $fmt($start) . ' - ' . $fmt($end);
    }

    private static function find_issued($prefix, $user_id, $course_id) {
        global $wpdb;
        $table = self::db_table();
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE prefix=%s AND user_id=%d AND course_id=%d AND status='issued' LIMIT 1",
            $prefix, $user_id, $course_id
        ));
        return $row ?: false;
    }

    /**
     * Создаёт запись с новым номером. Возвращает [row, is_new].
     */
    private static function next_serial_and_insert($prefix, $user_id, $course_id) {
        global $wpdb;
        $table = self::db_table();

        // 1) запрет на повторную выдачу — возвращаем существующий номер
        $existing = self::find_issued($prefix, $user_id, $course_id);
        if ($existing) return [$existing, false];

        // Номера, выданные старой версией плагина с тем же префиксом
        $legacy_last = 0;
        if (get_option(self::LEGACY_OPTION_PREFIX, 'TP1225') === $prefix) {
            $legacy_last = (int) get_option(self::LEGACY_OPTION_LAST_NUM, 0);
        }

        // 2) берём следующий serial и вставляем; если гонка (UNIQUE) — повторяем
        for ($i = 0; $i < 5; $i++) {
            $max = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(MAX(serial),0) FROM {$table} WHERE prefix=%s",
                $prefix
            ));
            $next = max($max, $legacy_last) + 1;

            $number_full = sprintf('%s-%03d', $prefix, $next);

            $ok = $wpdb->insert($table, [
                'prefix'      => $prefix,
                'serial'      => $next,
                'number_full' => $number_full,
                'user_id'     => $user_id,
                'course_id'   => $course_id,
                'issued_at'   => current_time('mysql'),
                'status'      => 'issued',
            ], ['%s', '%d', '%s', '%d', '%d', '%s', '%s']);

            if ($ok) {
                return [$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $wpdb->insert_id)), true];
            }
        }

        return new WP_Error('cert_number_fail', 'Не удалось создать уникальный номер сертификата. Попробуйте ещё раз.');
    }

    private static function coordinates() {
        // Координаты в мм для A4 (портрет) 210x297, подогнаны под шаблоны 595x842 px (1 px ≈ 0,353 мм).
        // Нижний блок (номер, дата) на обеих страницах одинаковый.
        $number = ['x' => 78, 'y' => 242, 'w' => 105, 'h' => 6, 'size' => 12, 'align' => 'L'];
        $date   = ['x' => 55, 'y' => 259, 'w' => 68,  'h' => 6, 'size' => 12, 'align' => 'C'];

        return [
            'cert' => [
                // ФИО — над линией под «Осымен / Настоящим подтверждает, что»
                'fio'    => ['x' => 24, 'y' => 96, 'w' => 160, 'h' => 8, 'size' => 16, 'align' => 'C'],
                'number' => $number,
                'date'   => $date,
            ],
            'appx' => [
                // ФИО — строка «АЖТ / ФИО»
                'fio'    => ['x' => 53,  'y' => 134, 'w' => 132, 'h' => 8, 'size' => 12, 'align' => 'C'],
                // Период — справа от «Дата проведения курса:»
                'period' => ['x' => 129, 'y' => 149, 'w' => 56,  'h' => 8, 'size' => 10, 'align' => 'C'],
                // Оценка — строка «Бағa / Оценка»
                'grade'  => ['x' => 56,  'y' => 194, 'w' => 129, 'h' => 8, 'size' => 12, 'align' => 'C'],
                'number' => $number,
                'date'   => $date,
            ],
        ];
    }

    private static function draw_text($pdf, $c, $text) {
        $pdf->SetFont('dejavusans', '', $c['size']);
        $pdf->SetXY($c['x'], $c['y']);
        $pdf->Cell($c['w'], $c['h'], $text, 0, 0, $c['align'], false, '', 1); // 1 = сжать по ширине, если не влезает
    }

    private static function build_pdf($data) {
        // $data: prefix, fio, number_full, issue_date, period, grade
        self::ensure_dirs();

        if (!self::ensure_tcpdf_loaded()) {
            return new WP_Error('tcpdf_missing',
                'TCPDF не найден. Положите библиотеку в: /wp-content/plugins/talim-certificates/lib/tcpdf/ (файл tcpdf.php).'
            );
        }

        $tpl = self::template_paths();
        if (!file_exists($tpl['cert']) || !file_exists($tpl['appx'])) {
            return new WP_Error('templates_missing',
                'Не найдены шаблоны. Положите файлы: ' .
                self::templates_dir() . '/certificate_bg.png и ' . self::templates_dir() . '/appendix_bg.png'
            );
        }

        $coords = self::coordinates();

        $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->SetMargins(0, 0, 0);
        $pdf->SetAutoPageBreak(false, 0);
        $pdf->SetTitle('Сертификат ' . $data['number_full']);

        // Стр. 1 сертификат
        $pdf->AddPage();
        $pdf->Image($tpl['cert'], 0, 0, 210, 297, '', '', '', false, 300, '', false, false, 0, false, false, false);
        self::draw_text($pdf, $coords['cert']['fio'], $data['fio']);
        self::draw_text($pdf, $coords['cert']['number'], $data['number_full']);
        self::draw_text($pdf, $coords['cert']['date'], $data['issue_date']);

        // Стр. 2 приложение
        $pdf->AddPage();
        $pdf->Image($tpl['appx'], 0, 0, 210, 297, '', '', '', false, 300, '', false, false, 0, false, false, false);
        self::draw_text($pdf, $coords['appx']['fio'], $data['fio']);
        self::draw_text($pdf, $coords['appx']['period'], $data['period']);
        self::draw_text($pdf, $coords['appx']['grade'], $data['grade']);
        self::draw_text($pdf, $coords['appx']['number'], $data['number_full']);
        self::draw_text($pdf, $coords['appx']['date'], $data['issue_date']);

        // сохраняем
        $dir = self::certs_dir() . '/' . sanitize_file_name($data['prefix']);
        if (!file_exists($dir)) wp_mkdir_p($dir);

        $path = $dir . '/' . sanitize_file_name($data['number_full']) . '.pdf';

        try {
            $pdf->Output($path, 'F');
        } catch (Exception $e) {
            return new WP_Error('pdf_write', $e->getMessage());
        }

        return file_exists($path) ? $path : new WP_Error('pdf_write', 'PDF не записан: ' . $path);
    }

    /**
     * Путь в БД: относительный от uploads (новые записи) или абсолютный (записи версии 1.0).
     */
    private static function resolve_pdf_path($stored) {
        if (empty($stored)) return '';
        if (file_exists($stored)) return $stored;
        $rel = self::uploads_dir() . '/' . ltrim($stored, '/\\');
        return file_exists($rel) ? $rel : '';
    }

    private static function relative_pdf_path($abs) {
        $base = self::uploads_dir() . '/';
        return strpos($abs, $base) === 0 ? substr($abs, strlen($base)) : $abs;
    }

    public static function handle_generate() {
        if (!current_user_can('manage_options')) wp_die('No access');
        check_admin_referer('talim_generate_certificate');

        $course_id = isset($_POST['course_id']) ? (int) $_POST['course_id'] : 0;
        $user_id   = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
        $grade     = isset($_POST['grade']) ? sanitize_text_field(wp_unslash($_POST['grade'])) : '';
        $back      = ['course_id' => $course_id, 'only_100' => 1];

        if (!$course_id || !$user_id) {
            self::redirect(['msg' => 'bad_request']);
        }

        $prefix = sanitize_text_field(get_option(self::OPTION_PREFIX, self::DEFAULT_PREFIX));
        if ($grade === '') $grade = get_option(self::OPTION_GRADE, self::DEFAULT_GRADE);

        // проверка 100%
        if (self::tutor_progress_percent($course_id, $user_id) < 100) {
            self::redirect($back + ['msg' => 'not_100']);
        }

        // создаём запись и номер (или берём уже выданный — тогда PDF пересоздаётся с тем же номером)
        $res = self::next_serial_and_insert($prefix, $user_id, $course_id);
        if (is_wp_error($res)) {
            self::redirect($back + ['msg' => 'number_fail']);
        }
        list($row, $is_new) = $res;

        $pdf_path = self::build_pdf([
            'prefix'      => $prefix,
            'fio'         => self::get_user_fullname($user_id),
            'number_full' => $row->number_full,
            'issue_date'  => date_i18n('d.m.Y', strtotime($row->issued_at)),
            'period'      => self::course_period($course_id, $user_id),
            'grade'       => $grade,
        ]);

        global $wpdb;
        $table = self::db_table();

        if (is_wp_error($pdf_path)) {
            // Новый номер освобождаем, чтобы не было «дыр» и можно было повторить
            if ($is_new) {
                $wpdb->delete($table, ['id' => (int) $row->id], ['%d']);
            }
            self::redirect($back + ['msg' => 'pdf_fail', 'err' => rawurlencode($pdf_path->get_error_message())]);
        }

        $wpdb->update($table, ['pdf_path' => self::relative_pdf_path($pdf_path)], ['id' => (int) $row->id]);

        self::redirect($back + ['msg' => $is_new ? 'issued' : 'regenerated']);
    }

    public static function handle_download() {
        if (!current_user_can('manage_options')) wp_die('No access');

        $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        check_admin_referer('talim_download_certificate_' . $id);

        global $wpdb;
        $table = self::db_table();
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $id));
        $path = $row ? self::resolve_pdf_path($row->pdf_path) : '';

        if (!$path) wp_die('Файл сертификата не найден. Сгенерируйте PDF заново.');

        nocache_headers();
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . sanitize_file_name($row->number_full) . '.pdf"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    public static function handle_save_settings() {
        if (!current_user_can('manage_options')) wp_die('No access');
        check_admin_referer('talim_save_cert_settings');

        $prefix = isset($_POST['prefix']) ? strtoupper(preg_replace('/[^A-Za-z0-9]/', '', wp_unslash($_POST['prefix']))) : '';
        $grade  = isset($_POST['grade']) ? sanitize_text_field(wp_unslash($_POST['grade'])) : '';

        if ($prefix !== '') update_option(self::OPTION_PREFIX, substr($prefix, 0, 20));
        if ($grade !== '')  update_option(self::OPTION_GRADE, $grade);

        self::redirect(['msg' => 'settings_saved']);
    }

    /**
     * ID студентов, записанных на курс (Tutor LMS), с поиском и пагинацией.
     */
    private static function enrolled_users($course_id, $s, $paged) {
        global $wpdb;

        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT post_author FROM {$wpdb->posts}
             WHERE post_type = 'tutor_enrolled' AND post_parent = %d AND post_status = 'completed' AND post_author > 0",
            $course_id
        ));

        if (!$ids) return [[], 0];

        $args = [
            'include' => array_map('intval', $ids),
            'number'  => self::PER_PAGE,
            'paged'   => $paged,
            'orderby' => 'ID',
            'order'   => 'DESC',
            'count_total' => true,
        ];
        if ($s) {
            $args['search'] = '*' . $s . '*';
            $args['search_columns'] = ['user_login', 'user_email', 'display_name'];
        }

        $q = new WP_User_Query($args);
        return [$q->get_results(), (int) $q->get_total()];
    }

    public static function page() {
        if (!current_user_can('manage_options')) return;

        self::ensure_dirs();

        $course_id = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
        $only_100  = isset($_GET['course_id']) ? (int)!empty($_GET['only_100']) : 1;
        $s         = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $msg       = isset($_GET['msg']) ? sanitize_key($_GET['msg']) : '';
        $err       = isset($_GET['err']) ? sanitize_text_field(wp_unslash($_GET['err'])) : '';
        $paged     = max(1, (int)($_GET['paged'] ?? 1));

        $prefix = sanitize_text_field(get_option(self::OPTION_PREFIX, self::DEFAULT_PREFIX));
        $default_grade = get_option(self::OPTION_GRADE, self::DEFAULT_GRADE);

        $courses = get_posts([
            'post_type' => self::tutor_course_post_type(),
            'post_status' => 'publish',
            'numberposts' => 200,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        $users = [];
        $total = 0;
        if ($course_id) {
            list($users, $total) = self::enrolled_users($course_id, $s, $paged);
        }

        $tpl = self::template_paths();
        $tpl_ok = (file_exists($tpl['cert']) && file_exists($tpl['appx']));

        ?>
        <div class="wrap">
            <h1>Сертификаты</h1>

            <?php if (!$tpl_ok): ?>
                <div class="notice notice-warning">
                    <p><b>Шаблоны не найдены.</b> Положите файлы:</p>
                    <p>
                        <code><?php echo esc_html(self::templates_dir().'/certificate_bg.png'); ?></code><br>
                        <code><?php echo esc_html(self::templates_dir().'/appendix_bg.png'); ?></code>
                    </p>
                </div>
            <?php endif; ?>

            <?php if (!self::ensure_tcpdf_loaded()): ?>
                <div class="notice notice-error">
                    <p><b>TCPDF не найден.</b> Положите библиотеку сюда:</p>
                    <p><code><?php echo esc_html(plugin_dir_path(__FILE__) . 'lib/tcpdf/tcpdf.php'); ?></code></p>
                </div>
            <?php endif; ?>

            <?php if ($msg): ?>
                <?php
                $map = [
                    'issued' => ['success', 'Сертификат успешно сгенерирован.'],
                    'regenerated' => ['success', 'PDF пересоздан с прежним номером.'],
                    'settings_saved' => ['success', 'Настройки сохранены.'],
                    'not_100' => ['warning', 'Нельзя выдать сертификат: курс не завершён на 100%.'],
                    'pdf_fail' => ['error', 'Ошибка генерации PDF. Номер не израсходован, можно повторить.'],
                    'bad_request' => ['error', 'Некорректный запрос.'],
                    'number_fail' => ['error', 'Не удалось создать номер сертификата.'],
                ];
                list($type, $text) = $map[$msg] ?? ['info', $msg];
                ?>
                <div class="notice notice-<?php echo esc_attr($type); ?>"><p>
                    <?php echo esc_html($text); ?>
                    <?php if ($err): ?><br><small><?php echo esc_html($err); ?></small><?php endif; ?>
                </p></div>
            <?php endif; ?>

            <form method="get" style="margin: 12px 0;">
                <input type="hidden" name="page" value="talim-certificates" />

                <label><b>Курс:</b></label>
                <select name="course_id">
                    <option value="0">— выберите курс —</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?php echo (int)$c->ID; ?>" <?php selected($course_id, (int)$c->ID); ?>>
                            <?php echo esc_html($c->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                &nbsp;&nbsp;
                <label>
                    <input type="checkbox" name="only_100" value="1" <?php checked($only_100, 1); ?> />
                    показывать только завершивших курс
                </label>

                &nbsp;&nbsp;
                <input type="text" name="s" placeholder="поиск по email/логину/имени" value="<?php echo esc_attr($s); ?>" />
                <button class="button button-primary">Применить</button>
            </form>

            <table class="widefat striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>ФИО</th>
                    <th>Email</th>
                    <th>Прогресс</th>
                    <th>Сертификат</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php
                if (!$course_id) {
                    echo '<tr><td colspan="6">Выберите курс, чтобы увидеть записанных слушателей.</td></tr>';
                } elseif (!$users) {
                    echo '<tr><td colspan="6">На курс никто не записан или никто не найден по запросу.</td></tr>';
                }

                foreach ($users as $u) {
                    $uid = (int)$u->ID;

                    $progress = self::tutor_progress_percent($course_id, $uid);
                    $issued_row = self::find_issued($prefix, $uid, $course_id);

                    if ($only_100 && $progress < 100 && !$issued_row) continue;

                    $fio = self::get_user_fullname($uid);
                    $has_file = $issued_row && self::resolve_pdf_path($issued_row->pdf_path);

                    echo '<tr>';
                    echo '<td>'.esc_html($uid).'</td>';
                    echo '<td>'.esc_html($fio ?: $u->display_name).'</td>';
                    echo '<td>'.esc_html($u->user_email).'</td>';
                    echo '<td>'.esc_html($progress.'%').'</td>';

                    if ($issued_row) {
                        echo '<td><b>'.esc_html($issued_row->number_full).'</b><br><small>'.esc_html($issued_row->issued_at).'</small></td>';
                    } else {
                        echo '<td>—</td>';
                    }

                    echo '<td>';
                    if ($has_file) {
                        $dl = wp_nonce_url(
                            admin_url('admin-post.php?action=talim_download_certificate&id=' . (int)$issued_row->id),
                            'talim_download_certificate_' . (int)$issued_row->id
                        );
                        echo '<a class="button" target="_blank" href="'.esc_url($dl).'">Скачать PDF</a> ';
                    }

                    if ($progress >= 100) {
                        $label = $issued_row ? 'Пересоздать PDF' : 'Сгенерировать';
                        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline-flex;gap:6px;align-items:center;">';
                        wp_nonce_field('talim_generate_certificate');
                        echo '<input type="hidden" name="action" value="talim_generate_certificate" />';
                        echo '<input type="hidden" name="course_id" value="'.esc_attr($course_id).'" />';
                        echo '<input type="hidden" name="user_id" value="'.esc_attr($uid).'" />';
                        echo '<input type="text" name="grade" value="'.esc_attr($default_grade).'" class="small-text" style="width:90px" title="Оценка в приложении" />';
                        echo '<button class="button '.($issued_row ? '' : 'button-primary').'">'.esc_html($label).'</button>';
                        echo '</form>';
                    } elseif (!$issued_row) {
                        echo '<span class="description">Курс не завершён</span>';
                    }
                    echo '</td>';

                    echo '</tr>';
                }
                ?>
                </tbody>
            </table>

            <?php
            $pages = (int) ceil($total / self::PER_PAGE);
            if ($pages > 1) {
                echo '<div class="tablenav"><div class="tablenav-pages">';
                echo paginate_links([
                    'base'    => add_query_arg('paged', '%#%'),
                    'format'  => '',
                    'current' => $paged,
                    'total'   => $pages,
                ]);
                echo '</div></div>';
            }
            ?>

            <hr>
            <h2>Настройки</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('talim_save_cert_settings'); ?>
                <input type="hidden" name="action" value="talim_save_cert_settings" />
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="talim-prefix">Префикс номера</label></th>
                        <td>
                            <input id="talim-prefix" type="text" name="prefix" value="<?php echo esc_attr($prefix); ?>" class="regular-text" />
                            <p class="description">Номер: <code><?php echo esc_html($prefix); ?>-001</code>. При смене префикса нумерация начнётся заново.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="talim-grade">Оценка по умолчанию</label></th>
                        <td><input id="talim-grade" type="text" name="grade" value="<?php echo esc_attr($default_grade); ?>" class="regular-text" /></td>
                    </tr>
                </table>
                <?php submit_button('Сохранить настройки'); ?>
            </form>

            <h2>Шаблоны и файлы</h2>
            <p>Шаблоны: <code><?php echo esc_html(self::templates_dir()); ?></code> — <code>certificate_bg.png</code>, <code>appendix_bg.png</code> (A4, рекомендуется 2480×3508 px).</p>
            <p>Готовые PDF: <code><?php echo esc_html(self::certs_dir()); ?></code> — папка закрыта от прямого доступа, скачивание только из этой страницы.</p>

        </div>
        <?php
    }
}

Talim_Certificates_Plugin::init();
