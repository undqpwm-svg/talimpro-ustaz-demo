<?php
/**
 * Plugin Name: Ustaz Tutor Vimeo Progress
 * Description: Контроль просмотра Vimeo-видео в уроках Tutor LMS + блокировка кнопки "Отметить как завершенный", пока урок не досмотрен до заданного процента.
 * Author: Ustaz Dev
 * Version: 1.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'USTAZ_VIMEO_VERSION', '1.3.0' );
define( 'USTAZ_VIMEO_REQUIRED_PERCENT', 90 ); // Порог просмотра в процентах (можно поменять фильтром ustaz_vimeo_required_percent)
define( 'USTAZ_VIMEO_MAX_SPEED', 2.5 );       // Во сколько раз просмотр может идти быстрее реального времени (скорость 2x + запас)
define( 'USTAZ_VIMEO_SLACK_SEC', 20 );        // Запас в секундах на задержки сети
define( 'USTAZ_VIMEO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'USTAZ_VIMEO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Проверка наличия Tutor LMS
 */
function ustaz_vimeo_has_tutor() {
	return function_exists( 'tutor_utils' ) && function_exists( 'tutor' );
}

function ustaz_vimeo_required_percent() {
	return (int) apply_filters( 'ustaz_vimeo_required_percent', USTAZ_VIMEO_REQUIRED_PERCENT );
}

function ustaz_vimeo_is_lesson( $lesson_id ) {
	return ustaz_vimeo_has_tutor() && get_post_type( $lesson_id ) === tutor()->lesson_post_type;
}

/**
 * Есть ли в уроке Vimeo-видео, которое нужно досмотреть.
 * Уроки без Vimeo (текст, PDF, другое видео) не блокируются.
 */
function ustaz_vimeo_lesson_requires_watch( $lesson_id ) {
	$lesson_id = (int) $lesson_id;
	if ( ! $lesson_id || ! ustaz_vimeo_is_lesson( $lesson_id ) ) {
		return false;
	}

	$requires = false;
	$video    = maybe_unserialize( get_post_meta( $lesson_id, '_video', true ) );

	if ( is_array( $video ) ) {
		$source = isset( $video['source'] ) ? $video['source'] : '';
		if ( 'vimeo' === $source && ! empty( $video['source_vimeo'] ) ) {
			$requires = true;
		}
		if ( 'embedded' === $source && ! empty( $video['source_embedded'] ) && false !== stripos( $video['source_embedded'], 'vimeo.com' ) ) {
			$requires = true;
		}
	}

	if ( ! $requires ) {
		$content = (string) get_post_field( 'post_content', $lesson_id );
		if ( false !== stripos( $content, 'player.vimeo.com' ) ) {
			$requires = true;
		}
	}

	return (bool) apply_filters( 'ustaz_vimeo_lesson_requires_watch', $requires, $lesson_id );
}

/**
 * Длительность видео из настроек урока Tutor (если преподаватель её указал), в секундах.
 */
function ustaz_vimeo_known_duration( $lesson_id ) {
	$video = maybe_unserialize( get_post_meta( $lesson_id, '_video', true ) );
	if ( ! is_array( $video ) ) {
		return 0;
	}
	if ( ! empty( $video['duration_sec'] ) ) {
		return (float) $video['duration_sec'];
	}
	if ( ! empty( $video['runtime'] ) && is_array( $video['runtime'] ) ) {
		$r   = $video['runtime'];
		$sec = (int) ( $r['hours'] ?? 0 ) * 3600 + (int) ( $r['minutes'] ?? 0 ) * 60 + (int) ( $r['seconds'] ?? 0 );
		return (float) $sec;
	}
	return 0;
}

/**
 * Сортирует и склеивает отрезки просмотра [[start, end], ...], обрезает их по длительности.
 */
function ustaz_vimeo_merge_ranges( $ranges, $duration ) {
	$clean = array();
	foreach ( (array) $ranges as $r ) {
		if ( ! is_array( $r ) || count( $r ) < 2 ) {
			continue;
		}
		$s = max( 0, (float) $r[0] );
		$e = (float) $r[1];
		if ( $duration > 0 ) {
			$e = min( $e, $duration );
		}
		if ( $e > $s ) {
			$clean[] = array( $s, $e );
		}
	}

	usort(
		$clean,
		function ( $a, $b ) {
			return $a[0] <=> $b[0];
		}
	);

	$merged = array();
	foreach ( $clean as $r ) {
		$last = count( $merged ) - 1;
		if ( $last >= 0 && $r[0] <= $merged[ $last ][1] + 1 ) {
			$merged[ $last ][1] = max( $merged[ $last ][1], $r[1] );
		} else {
			$merged[] = $r;
		}
	}

	// Ограничиваем размер хранимых данных
	return array_slice( $merged, 0, 500 );
}

function ustaz_vimeo_ranges_total( $ranges ) {
	$total = 0;
	foreach ( $ranges as $r ) {
		$total += $r[1] - $r[0];
	}
	return $total;
}

function ustaz_vimeo_get_state( $lesson_id, $user_id ) {
	$state = get_user_meta( (int) $user_id, 'ustaz_vimeo_watch_' . (int) $lesson_id, true );
	if ( ! is_array( $state ) ) {
		$state = array();
	}
	return wp_parse_args(
		$state,
		array(
			'ranges' => array(),
			'dur'    => 0,
			'ts'     => 0,
		)
	);
}

/**
 * Получение прогресса просмотра урока (0–100)
 */
function ustaz_vimeo_get_progress( $lesson_id, $user_id ) {
	$lesson_id = (int) $lesson_id;
	$user_id   = (int) $user_id;

	if ( ! $lesson_id || ! $user_id ) {
		return 0;
	}

	$state   = ustaz_vimeo_get_state( $lesson_id, $user_id );
	$percent = 0;
	if ( $state['dur'] > 0 ) {
		$percent = (int) floor( ustaz_vimeo_ranges_total( $state['ranges'] ) / $state['dur'] * 100 );
	}

	// Прогресс, сохранённый версией 1.2 (процент позиции в видео)
	$legacy = (int) get_user_meta( $user_id, 'ustaz_vimeo_progress_' . $lesson_id, true );

	return min( 100, max( $percent, $legacy ) );
}

/**
 * Можно ли пользователю завершить урок
 */
function ustaz_vimeo_can_complete( $lesson_id, $user_id ) {
	if ( ! ustaz_vimeo_lesson_requires_watch( $lesson_id ) ) {
		return true;
	}
	// Администраторы и преподаватели курса проверку не проходят
	if ( user_can( $user_id, 'edit_post', $lesson_id ) ) {
		return true;
	}
	return ustaz_vimeo_get_progress( $lesson_id, $user_id ) >= ustaz_vimeo_required_percent();
}

/**
 * Подключаем JS только на страницах уроков Tutor LMS с Vimeo-видео
 */
add_action(
	'wp_enqueue_scripts',
	function () {

		if ( ! ustaz_vimeo_has_tutor() || ! is_user_logged_in() ) {
			return;
		}

		if ( ! is_singular( tutor()->lesson_post_type ) ) {
			return;
		}

		$lesson_id = (int) get_queried_object_id();
		$user_id   = get_current_user_id();

		if ( ! ustaz_vimeo_lesson_requires_watch( $lesson_id ) || ustaz_vimeo_can_complete( $lesson_id, $user_id ) ) {
			return;
		}

		wp_enqueue_script(
			'ustaz-tutor-vimeo-progress',
			USTAZ_VIMEO_PLUGIN_URL . 'assets/js/ustaz-tutor-vimeo-progress.js',
			array(),
			USTAZ_VIMEO_VERSION,
			true
		);

		wp_localize_script(
			'ustaz-tutor-vimeo-progress',
			'UstazVimeoProgress',
			array(
				'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
				'nonce'           => wp_create_nonce( 'ustaz_vimeo_progress' ),
				'lessonId'        => $lesson_id,
				'requiredPercent' => ustaz_vimeo_required_percent(),
				'currentPercent'  => ustaz_vimeo_get_progress( $lesson_id, $user_id ),
				'lockedText'      => sprintf( 'Досмотрите видео минимум на %d%%, чтобы завершить урок', ustaz_vimeo_required_percent() ),
			)
		);
	}
);

/**
 * AJAX: сохранение просмотренных отрезков видео
 */
add_action( 'wp_ajax_ustaz_save_vimeo_progress', 'ustaz_ajax_save_vimeo_progress' );

function ustaz_ajax_save_vimeo_progress() {

	if ( ! ustaz_vimeo_has_tutor() ) {
		wp_send_json_error( array( 'message' => 'Tutor LMS required' ) );
	}

	check_ajax_referer( 'ustaz_vimeo_progress', 'nonce' );

	$lesson_id = isset( $_POST['lesson_id'] ) ? (int) $_POST['lesson_id'] : 0;
	$duration  = isset( $_POST['duration'] ) ? (float) $_POST['duration'] : 0;
	$ranges    = isset( $_POST['ranges'] ) ? json_decode( wp_unslash( $_POST['ranges'] ), true ) : null;
	$user_id   = get_current_user_id();

	if ( ! $lesson_id || ! is_array( $ranges ) || ! ustaz_vimeo_lesson_requires_watch( $lesson_id ) ) {
		wp_send_json_error( array( 'message' => 'Bad data' ) );
	}

	if ( method_exists( tutor_utils(), 'has_enrolled_content_access' ) && ! tutor_utils()->has_enrolled_content_access( 'lesson', $lesson_id ) ) {
		wp_send_json_error( array( 'message' => 'Access denied' ) );
	}

	$state = ustaz_vimeo_get_state( $lesson_id, $user_id );

	// Длительность: из настроек урока, иначе первая присланная плеером (потом не меняется)
	$known = ustaz_vimeo_known_duration( $lesson_id );
	if ( $known > 0 ) {
		$state['dur'] = $known;
	} elseif ( $state['dur'] <= 0 && $duration > 0 ) {
		$state['dur'] = $duration;
	}

	if ( $state['dur'] <= 0 ) {
		wp_send_json_error( array( 'message' => 'Unknown duration' ) );
	}

	$old_total = ustaz_vimeo_ranges_total( $state['ranges'] );
	$merged    = ustaz_vimeo_merge_ranges( array_merge( $state['ranges'], $ranges ), $state['dur'] );
	$added     = ustaz_vimeo_ranges_total( $merged ) - $old_total;

	// Нельзя «посмотреть» больше, чем позволяет прошедшее время.
	// Клиент каждый раз присылает все отрезки сессии, поэтому отклонённое сейчас засчитается позже.
	$now     = time();
	$last_ts = $state['ts'] ? (int) $state['ts'] : $now;
	$allowed = ( $now - $last_ts ) * USTAZ_VIMEO_MAX_SPEED + USTAZ_VIMEO_SLACK_SEC;

	if ( $added > $allowed ) {
		wp_send_json_success(
			array(
				'percent'  => ustaz_vimeo_get_progress( $lesson_id, $user_id ),
				'accepted' => false,
			)
		);
	}

	if ( $added > 0 || ! $state['ts'] ) {
		$state['ranges'] = $merged;
		$state['ts']     = $now;
		update_user_meta( $user_id, 'ustaz_vimeo_watch_' . $lesson_id, $state );
	}

	$percent = ustaz_vimeo_get_progress( $lesson_id, $user_id );

	wp_send_json_success(
		array(
			'percent'  => $percent,
			'accepted' => true,
			'unlocked' => $percent >= ustaz_vimeo_required_percent(),
		)
	);
}

/**
 * Серверная защита формы «Отметить как завершенный» (Tutor: Lesson::mark_lesson_complete)
 */
add_filter( 'tutor_validate_lesson_complete', 'ustaz_vimeo_validate_lesson_complete', 10, 3 );

function ustaz_vimeo_validate_lesson_complete( $validated, $user_id, $lesson_id ) {
	if ( ! $validated || ustaz_vimeo_can_complete( $lesson_id, $user_id ) ) {
		return $validated;
	}

	$redirect = add_query_arg(
		array(
			'ustaz_vimeo_error' => 1,
			'ustaz_percent'     => ustaz_vimeo_get_progress( $lesson_id, $user_id ),
		),
		get_permalink( $lesson_id )
	);

	wp_safe_redirect( $redirect );
	exit;
}

/**
 * Серверная защита автозавершения урока по окончании видео (Tutor: Ajax::sync_video_playback, is_ended=1)
 */
add_action( 'wp_ajax_sync_video_playback', 'ustaz_vimeo_guard_sync_playback', 1 );

function ustaz_vimeo_guard_sync_playback() {
	if ( empty( $_POST['is_ended'] ) || empty( $_POST['post_id'] ) ) {
		return;
	}
	$lesson_id = (int) $_POST['post_id'];
	if ( ! ustaz_vimeo_can_complete( $lesson_id, get_current_user_id() ) ) {
		unset( $_POST['is_ended'], $_REQUEST['is_ended'] );
	}
}

/**
 * Сообщение на уроке, если пробовали завершить без достаточного просмотра
 */
add_action(
	'tutor_lesson/single/before/content',
	function () {

		if ( empty( $_GET['ustaz_vimeo_error'] ) ) {
			return;
		}

		$percent  = isset( $_GET['ustaz_percent'] ) ? (int) $_GET['ustaz_percent'] : 0;
		$required = ustaz_vimeo_required_percent();
		?>
	<div class="tutor-alert tutor-alert-warning"
		style="margin-bottom:20px;padding:15px;border-left:4px solid #F9731E;background:#FFF0C3;color:#000;">
		<strong>Урок ещё нельзя завершить.</strong><br>
		Вы посмотрели примерно <?php echo esc_html( $percent ); ?>% видео, а требуется минимум <?php echo esc_html( $required ); ?>%.
		Перемотка не засчитывается. Пожалуйста, досмотрите видео и снова нажмите «Отметить как завершенный».
	</div>
		<?php
	}
);
