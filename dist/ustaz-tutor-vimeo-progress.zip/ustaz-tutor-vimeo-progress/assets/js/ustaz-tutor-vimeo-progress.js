(function() {
    // Проверяем, что PHP передал нам данные
    if (typeof UstazVimeoProgress === 'undefined') {
        return;
    }

    var cfg             = UstazVimeoProgress;
    var lessonId        = parseInt(cfg.lessonId, 10);
    var requiredPercent = parseInt(cfg.requiredPercent, 10) || 90;
    var serverPercent   = parseInt(cfg.currentPercent, 10) || 0;

    var SEND_EVERY_MS = 15000; // как часто отправлять прогресс во время просмотра
    var MAX_TICK_SEC  = 1.5;   // больший скачок времени считаем перемоткой и не засчитываем

    var unlocked = serverPercent >= requiredPercent;
    var started  = false;

    // ---------- Кнопки завершения урока ----------

    function getCompleteButtons() {
        return Array.prototype.slice.call(
            document.querySelectorAll('button[name="complete_lesson_btn"], .tutor-topbar-mark-btn')
        );
    }

    function lockCompleteButtons() {
        if (unlocked) return;
        getCompleteButtons().forEach(function(btn) {
            btn.classList.add('ustaz-complete-disabled');
            btn.disabled = true;
            btn.title = cfg.lockedText || '';
            btn.style.opacity = '0.4';
            btn.style.cursor  = 'not-allowed';
        });
    }

    function unlockCompleteButtons() {
        unlocked = true;
        getCompleteButtons().forEach(function(btn) {
            btn.classList.remove('ustaz-complete-disabled');
            btn.disabled = false;
            btn.title = '';
            btn.style.opacity = '';
            btn.style.cursor  = '';
        });
    }

    // ---------- Учёт просмотренных отрезков ----------

    var ranges   = [];   // [[start, end], ...] за эту сессию
    var current  = null; // отрезок, который сейчас растёт
    var lastTime = null;
    var duration = 0;
    var dirty    = false;

    function track(seconds) {
        if (lastTime !== null && seconds > lastTime && seconds - lastTime <= MAX_TICK_SEC) {
            if (current && current[1] === lastTime) {
                current[1] = seconds;
            } else {
                current = [lastTime, seconds];
                ranges.push(current);
            }
            dirty = true;
        } else {
            current = null; // перемотка или пауза — начинаем новый отрезок
        }
        lastTime = seconds;
    }

    function round(r) {
        return [Math.round(r[0] * 10) / 10, Math.round(r[1] * 10) / 10];
    }

    // Отправка отрезков на сервер. Сервер сам считает процент и решает, можно ли завершить урок.
    function sendProgress() {
        if (!dirty || !duration) return;
        dirty = false;

        var body = new URLSearchParams();
        body.append('action', 'ustaz_save_vimeo_progress');
        body.append('nonce', cfg.nonce);
        body.append('lesson_id', String(lessonId));
        body.append('duration', String(duration));
        body.append('ranges', JSON.stringify(ranges.map(round)));

        fetch(cfg.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString()
        })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (!res || !res.success) return;
                if (res.data && res.data.accepted === false) {
                    dirty = true; // сервер принял не всё — повторим позже
                }
                if (res.data && res.data.unlocked) {
                    unlockCompleteButtons();
                }
            })
            .catch(function(err) {
                dirty = true;
                console.error('[UstazVimeo] Ошибка отправки прогресса', err);
            });
    }

    function setupPlayer(iframe) {
        if (typeof Vimeo === 'undefined' || !Vimeo.Player) return;

        var player = new Vimeo.Player(iframe);

        player.getDuration().then(function(d) { duration = d; }).catch(function() {});

        player.on('timeupdate', function(data) {
            if (!data) return;
            if (data.duration) duration = data.duration;
            track(data.seconds);
        });
        player.on('seeked', function(data) {
            current  = null;
            lastTime = data ? data.seconds : null;
        });
        player.on('pause', sendProgress);
        player.on('ended', sendProgress);

        setInterval(sendProgress, SEND_EVERY_MS);
        window.addEventListener('pagehide', sendProgress);
    }

    function findIframe() {
        return document.querySelector('.tutor-video-player iframe[src*="vimeo.com"], iframe[src*="player.vimeo.com"]');
    }

    function start(iframe) {
        if (started) return;
        started = true;

        if (typeof Vimeo === 'undefined') {
            var s = document.createElement('script');
            s.src = 'https://player.vimeo.com/api/player.js';
            s.onload = function() { setupPlayer(iframe); };
            document.head.appendChild(s);
        } else {
            setupPlayer(iframe);
        }
    }

    // ---------- Запуск ----------

    lockCompleteButtons();

    // Кнопки и плеер могут появиться позже (ленивая загрузка) — следим за DOM
    var observer = new MutationObserver(function() {
        lockCompleteButtons();
        var iframe = findIframe();
        if (iframe) start(iframe);
    });
    observer.observe(document.body, { childList: true, subtree: true });

    var iframe = findIframe();
    if (iframe) start(iframe);

    // Через 15 секунд DOM уже стабилен — наблюдатель больше не нужен
    setTimeout(function() { observer.disconnect(); }, 15000);
})();
