<?php
/**
 * Plugin Name: Talim.Pro Brand
 * Description: Фирменный стиль talim.pro (брендбук 2025): шрифт Inter, цвета #3458F1 / #F9731E для темы Astra, Tutor LMS и страницы входа.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TALIMPRO_BRAND_VERSION', '1.0.0' );
define( 'TALIMPRO_BRAND_URL', plugin_dir_url( __FILE__ ) );

/**
 * Цвета брендбука
 */
function talimpro_brand_colors() {
	return array(
		'blue'        => '#3458F1',
		'blue_hover'  => '#2A47D1',
		'orange'      => '#F9731E',
		'black'       => '#000000',
		'white'       => '#FFFFFF',
	);
}

/**
 * Tutor LMS берёт цвета из своих настроек — подменяем их, чтобы переменные
 * --tutor-color-primary и --tutor-color-primary-rgb совпадали с брендом.
 */
add_filter(
	'option_tutor_option',
	function ( $options ) {
		if ( is_admin() || ! is_array( $options ) ) {
			return $options;
		}
		$c = talimpro_brand_colors();

		$options['tutor_primary_color']       = $c['blue'];
		$options['tutor_primary_hover_color'] = $c['blue_hover'];
		$options['tutor_text_color']          = '#111111';

		return $options;
	}
);

function talimpro_brand_enqueue() {
	wp_enqueue_style(
		'talimpro-inter',
		'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap',
		array(),
		null
	);
	wp_enqueue_style(
		'talimpro-brand',
		TALIMPRO_BRAND_URL . 'assets/brand.css',
		array( 'talimpro-inter' ),
		TALIMPRO_BRAND_VERSION
	);
}

// Поздний приоритет — чтобы стили шли после Astra и Tutor
add_action( 'wp_enqueue_scripts', 'talimpro_brand_enqueue', 100 );
add_action( 'login_enqueue_scripts', 'talimpro_brand_enqueue', 100 );

add_action(
	'wp_head',
	function () {
		echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
		echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
		echo '<meta name="theme-color" content="#3458F1">' . "\n";
	},
	1
);

/**
 * Страница входа: ссылка логотипа ведёт на сайт, а не на wordpress.org
 */
add_filter(
	'login_headerurl',
	function () {
		return home_url( '/' );
	}
);
add_filter(
	'login_headertext',
	function () {
		return 'talim.pro';
	}
);
